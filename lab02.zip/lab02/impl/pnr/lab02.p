`pragma protect begin_protected
`pragma protect version="1.0"
`pragma protect author="default"
`pragma protect author_info="default"
`pragma protect encrypt_agent="GOWIN"
`pragma protect encrypt_agent_info="GOWIN Encrypt Version 1.0"

`pragma protect encoding=(enctype="base64", line_length=76, bytes=256)
`pragma protect key_keyowner="GOWIN",key_keyname="GWK2022-11",key_method="rsa"
`pragma protect key_block
on77EfPFo63PoVUchUzKVfo7uG5W3j/8I4p0cvqS6WrX1/mF6AFqYZ7wH2FKyNDmHm65yZRA+bQW
yY0TJ2dxpv6XRV6Z2M0d4KA2D8jrXNE0gOUE6/+Db46IMs47u+v/F6SaFZjO4gWInmZuPHbALLwo
Rsq9YyEHKm/DtmjV9jSh8JR7dzNx1X5FaXlPwHyCeO6gdTUykzer0h3qE5OHxY+2QKFqgRxj+29P
SytD1NumuUz89PtSjGe1KGCMlyX8JwjJXUBSwHOOe6bsVsqBUxkpVR8Dm5LUXD/9EVev1rwSUrwO
Hobi/AyycBVHHYwEGu4duy+0442Mjz32PC2ZPQ==

`pragma protect encoding=(enctype="base64", line_length=76, bytes=240)
`pragma protect data_keyowner="default-ip-vendor"
`pragma protect data_keyname="default-ip-key"
`pragma protect data_method="aes128-cbc"
`pragma protect data_block
DoAfUbvvq169qH4o2DGXAOMJ1LcZul3+emOJzyCZcq0mTv0DvAtyxrQqFr3QTHHkPnH8y6z9sNxl
rB+ItdAQLW7e8NmqVELapdf50iTIAnRIVjJybXVznRiixDDOVzaKtYp7kpopon1qYAUcFMTTjn9c
k/cw4BWa0jUvSmMCyPOiPhl+HJmRPTdOpCS845sQ6cV2vjGJOnAQcscPLHxS7QJwv7KYkm9Ql/MR
+vulAgv/sOPPzJME/FdV/DpM9sYZ3/vrUVEFYCY7Mx+Qjn0Dx0eNb3xnR8yBCDhGR1+MqHkIr6Y/
sb3c6+lf2i70z9ki
`pragma protect end_protected
