library ieee;
use ieee.std_logic_1164.all;
use ieee.numeric_std.all;

entity lab02 is
  port (
    bt1 : in  std_logic;
    bt2 : in  std_logic;

    led : out std_logic
  );
end entity lab02;

architecture logic of lab02 is
begin
    led <= bt1 and bt2;
end architecture logic;
